/* CENTRIC — Website. Ohne Abhängigkeiten, ohne Tracking. */
(function () {
  "use strict";

  /* ── Navigation auf schmalen Bildschirmen ── */
  var burger = document.getElementById("burger");
  var nav = document.getElementById("nav");
  if (burger && nav) {
    burger.addEventListener("click", function () {
      var offen = nav.classList.toggle("offen");
      burger.setAttribute("aria-expanded", String(offen));
      burger.setAttribute("aria-label", offen ? "Navigation schließen" : "Navigation öffnen");
    });
  }

  /* ── Der Plan im Kopf der Startseite ──
     Dieselbe Arithmetik wie in der Anwendung: aus Zyklus und Versatz wird
     jeder Tag gerechnet. Deshalb kostet ein Sprung über zehn Jahre auch
     nichts — es gibt nichts auszurollen. */
  var buehne = document.getElementById("p-buehne");
  var gitter = document.getElementById("p-gitter");
  if (buehne && gitter) {
    var ZYKLUS = ["F","F","F","F","F","-","-","S","S","S","S","S","-","-","N","N","N","N","N","-","-","-","-","-"];
    var GRUPPEN = 6, VERSATZ = 4, WELLE = 9000;
    var EPOCHE = Date.UTC(2026, 0, 1);
    var TAG = 86400000;
    var WT = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
    var MON = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli",
               "August", "September", "Oktober", "November", "Dezember"];
    var KL = { F: "f", S: "s", N: "n", "-": "o" };
    var anzeige = document.getElementById("p-datum");
    var start = Date.UTC(2026, 7, 1);
    var n = 0;

    /* Eine Spalte mehr, als sichtbar ist — sonst reißt beim Weiterrücken
       am rechten Rand eine Lücke auf. */
    function spaltenzahl() {
      var breit = buehne.getBoundingClientRect().width;
      var pitch = parseFloat(getComputedStyle(buehne).getPropertyValue("--pitch")) || 26;
      var lab = window.innerWidth <= 820 ? 44 : 56;
      return Math.max(12, Math.ceil((breit - lab) / pitch) + 2);
    }

    function zellen() {
      var teile = [], i, g, d, wt, tag, ph;
      for (i = 0; i < n; i++) {
        d = new Date(start + i * TAG);
        wt = d.getUTCDay();
        teile.push('<span class="p-tag' + (wt === 0 || wt === 6 ? " we" : "") +
          '" style="--i:' + i + '"><i>' + WT[wt] + "</i><b>" +
          ("0" + d.getUTCDate()).slice(-2) + "</b></span>");
      }
      for (g = 0; g < GRUPPEN; g++) {
        for (i = 0; i < n; i++) {
          tag = Math.round((start + i * TAG - EPOCHE) / TAG);
          ph = (((tag * 90 + g * 420) % WELLE) + WELLE) % WELLE;
          var st = ZYKLUS[(((tag - g * VERSATZ) % 24) + 24) % 24];
          teile.push('<span class="p-z" style="--i:' + i + '"><i class="m ' +
            KL[st] + '" style="--ph:' + ph + '"></i></span>');
        }
      }
      return teile.join("");
    }

    function datum() {
      var d = new Date(start);
      anzeige.textContent = MON[d.getUTCMonth()] + " " + d.getUTCFullYear();
    }

    /* Neu rechnen: mit Einlauf, weil hier eine Entscheidung sichtbar wird. */
    var weg;
    function rechne() {
      n = spaltenzahl();
      gitter.style.setProperty("--spalten", n);
      gitter.innerHTML = zellen();
      datum();
      buehne.classList.add("frisch");
      clearTimeout(weg);
      weg = setTimeout(function () { buehne.classList.remove("frisch"); }, 1200);
    }

    /* Weiterrücken: ohne Einlauf, exakt dann, wenn der Schub bei null
       wieder anfängt — dadurch bleibt der Lauf ohne sichtbaren Sprung. */
    gitter.addEventListener("animationstart", function (e) {
      if (e.animationName !== "laufen") return;
      buehne.classList.remove("frisch");
    });
    gitter.addEventListener("animationiteration", function (e) {
      if (e.animationName !== "laufen") return;
      start += TAG;
      gitter.innerHTML = zellen();
      datum();
    });

    document.querySelectorAll("[data-spring]").forEach(function (b) {
      b.addEventListener("click", function () {
        var v = b.dataset.spring;
        if (v === "heute") {
          var h = new Date();
          start = Date.UTC(h.getFullYear(), h.getMonth(), 1);
        } else {
          start += Number(v) * TAG;
        }
        rechne();
      });
    });

    var t;
    window.addEventListener("resize", function () {
      clearTimeout(t); t = setTimeout(rechne, 180);
    });
    var heute = new Date();
    start = Date.UTC(heute.getFullYear(), heute.getMonth(), 1);
    rechne();
  }

  /* ── Ringregler ──
     Derselbe Aufbau wie das Bauteil für die Anwendung: der Ring ist unten
     offen, damit das Kleinste und das Größte nicht aneinanderstoßen; jede
     Raste ist einzeln antippbar; hell wird allein, was belegt ist; und ein
     Zug über mehr als die halbe Skala gilt als Überfahren des Anschlags,
     damit ein Daumen, der unten vorbeiwischt, nicht dreißig Standorte auf
     einen fallen lässt. */
  var LUECKE = 60, BOGEN = 300;

  function ringPunkt(r, grad) {
    var b = grad * Math.PI / 180;
    return [100 + r * Math.sin(b), 100 - r * Math.cos(b)];
  }
  function ringBogen(r, von, bis) {
    var a = ringPunkt(r, von), b = ringPunkt(r, bis);
    return "M " + a[0].toFixed(2) + " " + a[1].toFixed(2) + " A " + r + " " + r +
      " 0 " + (bis - von > 180 ? 1 : 0) + " 1 " + b[0].toFixed(2) + " " + b[1].toFixed(2);
  }
  function klemme(x, a, b) { return Math.min(b, Math.max(a, x)); }

  function ringregler(el, beiAenderung) {
    var min = Number(el.dataset.min), max = Number(el.dataset.max);
    var schritt = Number(el.dataset.schritt) || 1;
    var einheit = el.dataset.einheit || "";
    var stufen = Math.max(1, Math.floor((max - min) / schritt) + 1);
    var index = klemme(Math.round((Number(el.dataset.wert) - min) / schritt), 0, stufen - 1);
    var letzter = index, gefasst = false, aktiv = false;

    var NS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 200 200");
    svg.setAttribute("class", "ring-svg-regler");
    var spur = document.createElementNS(NS, "path");
    spur.setAttribute("d", ringBogen(78, -BOGEN / 2, BOGEN / 2));
    spur.setAttribute("class", "rr-spur");
    svg.appendChild(spur);

    /* Strichstärke und Segmentlänge folgen der Teilung. Die runden Enden
       tragen je die halbe Strichstärke über den Bogen hinaus — wer das
       nicht abzieht, bekommt bei dreißig Rasten einen durchgehenden
       Klumpen statt einzelner Marken. */
    var teilung = 2 * Math.PI * 78 * (BOGEN / 360) / stufen;
    var gesamt = teilung * 0.62;
    var dicke = klemme(gesamt, 4.5, 14);
    var halb = Math.max(0.3, (gesamt - dicke) / 2 / 78 * 180 / Math.PI);
    var teile = [];
    for (var i = 0; i < stufen; i++) {
      var w = stufen > 1 ? -BOGEN / 2 + BOGEN * i / (stufen - 1) : 0;
      var pfad = document.createElementNS(NS, "path");
      pfad.setAttribute("d", ringBogen(78, w - halb, w + halb));
      pfad.setAttribute("class", "rr-stufe");
      svg.appendChild(pfad);
      teile.push(pfad);
    }
    var zahl = document.createElementNS(NS, "text");
    zahl.setAttribute("x", "100"); zahl.setAttribute("y", "106");
    zahl.setAttribute("text-anchor", "middle"); zahl.setAttribute("class", "rr-zahl");
    svg.appendChild(zahl);
    if (einheit) {
      var eh = document.createElementNS(NS, "text");
      eh.setAttribute("x", "100"); eh.setAttribute("y", "128");
      eh.setAttribute("text-anchor", "middle"); eh.setAttribute("class", "rr-einheit");
      eh.textContent = einheit.toUpperCase();
      svg.appendChild(eh);
    }

    var scheibe = document.createElement("div");
    scheibe.className = "rr-scheibe";
    scheibe.tabIndex = 0;
    scheibe.setAttribute("role", "slider");
    scheibe.setAttribute("aria-valuemin", min);
    scheibe.setAttribute("aria-valuemax", max);
    if (el.dataset.lab) scheibe.setAttribute("aria-labelledby", el.dataset.lab);
    scheibe.appendChild(svg);

    var tasten = document.createElement("div");
    tasten.className = "rr-tasten";
    var weniger = document.createElement("button");
    var mehr = document.createElement("button");
    var spanne = document.createElement("span");
    spanne.textContent = min + " bis " + max;
    [weniger, mehr].forEach(function (t, n) {
      t.type = "button"; t.textContent = n ? "+" : "−";
      t.setAttribute("aria-label", (n ? "Erhöhen" : "Verringern"));
    });
    tasten.appendChild(weniger); tasten.appendChild(spanne); tasten.appendChild(mehr);

    el.appendChild(scheibe); el.appendChild(tasten);

    function wert() { return min + index * schritt; }
    function zeichne() {
      for (var i = 0; i < stufen; i++) {
        var belegt = i <= index, griff = i === index;
        teile[i].setAttribute("class",
          "rr-stufe" + (belegt ? " -belegt" : "") + (griff ? " -griff" : ""));
        teile[i].style.strokeWidth =
          belegt ? (griff ? dicke + 4 : dicke) + "px" : "2.2px";
      }
      svg.classList.toggle("-aktiv", aktiv);
      zahl.textContent = wert().toLocaleString("de-DE");
      scheibe.setAttribute("aria-valuenow", wert());
      scheibe.setAttribute("aria-valuetext", wert() + (einheit ? " " + einheit : ""));
      weniger.disabled = index <= 0; mehr.disabled = index >= stufen - 1;
    }
    function setze(i) {
      i = klemme(i, 0, stufen - 1);
      if (i === index) return;
      index = i; zeichne(); if (beiAenderung) beiAenderung();
    }
    function ausZeiger(ev) {
      var k = svg.getBoundingClientRect();
      var a = Math.atan2(ev.clientX - (k.left + k.width / 2),
                         -(ev.clientY - (k.top + k.height / 2))) * 180 / Math.PI;
      a = klemme(a, -BOGEN / 2, BOGEN / 2);
      return stufen > 1 ? Math.round((a + BOGEN / 2) / BOGEN * (stufen - 1)) : 0;
    }

    scheibe.addEventListener("pointerdown", function (ev) {
      ev.preventDefault(); gefasst = true; aktiv = true;
      scheibe.setPointerCapture(ev.pointerId);
      letzter = ausZeiger(ev); setze(letzter); zeichne();
    });
    scheibe.addEventListener("pointermove", function (ev) {
      if (!gefasst) return;
      var i = ausZeiger(ev);
      if (Math.abs(i - letzter) > Math.max(2, stufen / 2)) {
        i = letzter < stufen / 2 ? 0 : stufen - 1;
      }
      letzter = i; setze(i);
    });
    ["pointerup", "pointercancel"].forEach(function (n) {
      scheibe.addEventListener(n, function () { gefasst = false; });
    });
    scheibe.addEventListener("focus", function () { aktiv = true; zeichne(); });
    scheibe.addEventListener("blur", function () { aktiv = false; gefasst = false; zeichne(); });
    scheibe.addEventListener("keydown", function (ev) {
      var d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[ev.key];
      if (d !== undefined) { ev.preventDefault(); setze(index + d); return; }
      if (ev.key === "PageUp") { ev.preventDefault(); setze(index + 5); return; }
      if (ev.key === "PageDown") { ev.preventDefault(); setze(index - 5); return; }
      if (ev.key === "Home") { ev.preventDefault(); setze(0); return; }
      if (ev.key === "End") { ev.preventDefault(); setze(stufen - 1); }
    });
    weniger.addEventListener("click", function () { setze(index - 1); });
    mehr.addEventListener("click", function () { setze(index + 1); });

    zeichne();
    return { wert: wert };
  }

  /* ── Preisrechner ──
     Dieselbe Rechnung wie in der Anwendung, Zeile für Zeile: Grundgebühr
     der Stufe, Pauschale je Planer-Zugang über deren Kontingent, Zuschlag
     je Standort über deren Kontingent — gestaffelt nach der Größe DIESES
     Standorts, nicht nach der des Betriebs — und die Branchenpakete je
     Betrieb. Die Zahlen stehen in stufen.js im Anwendungsrepo; eine
     zweite, abweichende Rechnung an dieser Stelle wäre ein
     Preisversprechen, das die Anwendung nicht einhält. */
  var STUFEN = [{id:"basis",name:"Basis",grund:89,planerInkl:1,standorteInkl:1,paketeFrei:0},{id:"pro",name:"Business",grund:159,planerInkl:3,standorteInkl:2,paketeFrei:0},{id:"enterprise",name:"Enterprise",grund:279,planerInkl:8,standorteInkl:4,paketeFrei:2}];
  var BAENDER = [{bis:14,zuschlag:0},{bis:40,zuschlag:29},{bis:80,zuschlag:49},{bis:150,zuschlag:79},{bis:null,zuschlag:119}];
  var ZUSATZ_PLANER = 25;
  var KONTAKT_AB_PLANER = 16;
  var KONTAKT_AB_STANDORTE = 9;

  function standortZuschlag(personen) {
    for (var i = 0; i < BAENDER.length; i++)
      if (BAENDER[i].bis === null || personen <= BAENDER[i].bis) return BAENDER[i].zuschlag;
    return BAENDER[BAENDER.length - 1].zuschlag;
  }
  function eur(n) {
    return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  /* Was die gewählten Pakete kosten. Die in der Stufe enthaltenen sind
     die teuersten der gewählten — alles andere wäre eine Falle: Wer
     Pflege und Klinik hat und Industrie dazunimmt, dürfte sonst
     schlechter dastehen als vorher. */
  function paketkosten(gewaehlt, frei) {
    var sortiert = gewaehlt.slice().sort(function (a, b) { return b.preis - a.preis; });
    var offen = sortiert.slice(Math.max(0, frei));
    var summe = 0;
    for (var i = 0; i < offen.length; i++) summe += offen[i].preis;
    return { frei: sortiert.slice(0, Math.max(0, frei)), zahlend: offen, summe: summe };
  }

  function preisFuer(stufe, planer, standorte, pakete) {
    var zusatzPlaner = Math.max(0, planer - stufe.planerInkl);
    var summePlaner = zusatzPlaner * ZUSATZ_PLANER;
    /* Die größten Standorte zählen ins Kontingent — ein Betrieb muss
       nichts auswählen, um den günstigsten Fall zu bekommen. */
    var sortiert = standorte.slice().sort(function (a, b) { return b - a; });
    var posten = sortiert.slice(stufe.standorteInkl).map(function (n) {
      return { personen: n, zuschlag: standortZuschlag(n) };
    });
    var summeStandorte = 0;
    for (var i = 0; i < posten.length; i++) summeStandorte += posten[i].zuschlag;
    var pk = paketkosten(pakete, stufe.paketeFrei);
    return {
      stufe: stufe, zusatzPlaner: zusatzPlaner, summePlaner: summePlaner,
      posten: posten, summeStandorte: summeStandorte, pakete: pk,
      gesamt: Math.round((stufe.grund + summePlaner + summeStandorte + pk.summe) * 100) / 100,
      kontakt: planer > KONTAKT_AB_PLANER || posten.length > KONTAKT_AB_STANDORTE
    };
  }

  /* Die kleinste Stufe, die das gewählte Planer-Kontingent ohne Aufpreis
     trägt — die ehrlichste Antwort auf „was brauche ich". */
  function passendeStufe(planer) {
    for (var i = 0; i < STUFEN.length; i++)
      if (planer <= STUFEN[i].planerInkl) return STUFEN[i];
    return STUFEN[STUFEN.length - 1];
  }

  var form = document.getElementById("preisrechner");
  if (form) {
    var elSumme = document.getElementById("summe");
    var elZeilen = document.getElementById("zeilen");
    var elKopf = document.getElementById("jekopf");
    var elStufe = document.getElementById("stufe");

    var regler = {};
    form.querySelectorAll(".ring").forEach(function (el) {
      regler[el.id.replace("ring-", "")] = ringregler(el, function () { rechne(); });
    });

    var rechne = function () {
      var planer = regler.planer.wert();
      var n = regler.standorte.wert();
      var p = regler.personen.wert();

      var standorte = [];
      for (var i = 0; i < n; i++) standorte.push(p);

      var pakete = [];
      form.querySelectorAll("input[name=paket]:checked").forEach(function (c) {
        pakete.push({ id: c.value, preis: Number(c.dataset.preis),
          name: c.parentNode.querySelector("b").textContent.trim() });
      });

      var stufe = passendeStufe(planer);
      var r = preisFuer(stufe, planer, standorte, pakete);

      if (elStufe) elStufe.textContent = stufe.name;
      elSumme.textContent = r.kontakt ? "\u2014" : eur(r.gesamt);

      var zeilen = "";
      zeilen += "<dt>Grundgeb\u00fchr " + stufe.name + "</dt><dd>" +
                eur(stufe.grund) + " \u20ac</dd>";
      if (r.zusatzPlaner > 0)
        zeilen += "<dt>" + r.zusatzPlaner + " Planer-Zugang" +
                  (r.zusatzPlaner === 1 ? "" : "e") + " \u00fcber dem Kontingent</dt><dd>" +
                  eur(r.summePlaner) + " \u20ac</dd>";
      if (r.posten.length > 0)
        zeilen += "<dt>" + r.posten.length + " Standort" +
                  (r.posten.length === 1 ? "" : "e") + " \u00fcber dem Kontingent</dt><dd>" +
                  eur(r.summeStandorte) + " \u20ac</dd>";
      for (var j = 0; j < r.pakete.zahlend.length; j++)
        zeilen += "<dt>Paket " + r.pakete.zahlend[j].name + "</dt><dd>" +
                  eur(r.pakete.zahlend[j].preis) + " \u20ac</dd>";
      for (var k = 0; k < r.pakete.frei.length; k++)
        zeilen += "<dt>Paket " + r.pakete.frei[k].name +
                  " \u2014 in " + stufe.name + " enthalten</dt><dd>0,00 \u20ac</dd>";
      elZeilen.innerHTML = zeilen;

      if (r.kontakt) {
        elKopf.textContent = "Ein Betrieb dieser Gr\u00f6\u00dfe bekommt ein eigenes " +
          "Angebot mit verhandelter Grundgeb\u00fchr \u2014 sprechen Sie uns an.";
        return;
      }
      var koepfe = n * p;
      elKopf.textContent = "Das sind " + eur(r.gesamt / koepfe) +
        " \u20ac je Person und Monat bei " + koepfe.toLocaleString("de-DE") +
        " Personen \u2014 und diese Zahl f\u00e4llt weiter, wenn Sie morgen " +
        "zehn weitere einstellen. Wer geplant wird, kostet nichts.";
    };

    form.addEventListener("input", rechne);
    form.addEventListener("change", rechne);
    form.addEventListener("submit", function (e) { e.preventDefault(); });
    rechne();
  }

  /* ── Kontaktformular: baut eine E-Mail, überträgt selbst nichts ── */
  var kform = document.getElementById("kform");
  if (kform) {
    kform.addEventListener("submit", function (e) {
      e.preventDefault();
      var hinweis = document.getElementById("k-hinweis");
      if (!kform.checkValidity()) {
        kform.reportValidity();
        hinweis.textContent = "Bitte füllen Sie die Pflichtfelder aus.";
        return;
      }
      var f = kform.elements;
      var zeilen = [
        "Anliegen: " + f.anliegen.value,
        "Name: " + f.name.value,
        "Betrieb: " + f.betrieb.value,
        "E-Mail: " + f.mail.value,
        "Telefon: " + (f.tel.value || "—"),
        "Branche: " + f.branche.value,
        "Standorte: " + f.standorte.value,
        "",
        f.text.value || "—"
      ].join("\n");
      var url = "mailto:info@centric-dienstplanung.de" +
        "?subject=" + encodeURIComponent("CENTRIC — " + f.anliegen.value + " — " + f.betrieb.value) +
        "&body=" + encodeURIComponent(zeilen);
      window.location.href = url;
      hinweis.textContent = "Ihr E-Mail-Programm wurde geöffnet. Senden Sie die Nachricht ab, " +
        "dann melden wir uns am selben Werktag.";
    });
  }
})();
