/* CENTRIC — Spiegelhalle.
   Der Kopf der Startseite: eine Rotunde aus 26 leuchtenden Tafeln über
   stillem, spiegelndem Wasser. Ziehen dreht den Ring (mit Nachlauf),
   Überfahren hebt eine Tafel an, der Zeiger hinterlässt Ringe im Wasser.
   Die Spiegelung ist echt: eine gespiegelte Kamera zeichnet die Szene in
   eine Textur, die die Wellen verzerren. Drei.js liegt lokal bei —
   nichts wird nachgeladen. Bei reduzierter Bewegung steht die Halle und
   wird nur auf Eingaben neu gezeichnet. */
(function () {
  "use strict";
  document.documentElement.classList.add("halle-js");
  var abschnitt = document.getElementById("halle");
  var leinwand = document.getElementById("halle-c");
  requestAnimationFrame(function () { document.body.classList.add("-bereit"); });
  if (!abschnitt || !leinwand) return;
  if (!window.THREE) { abschnitt.classList.add("flach"); return; }

  var ruhig = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var T = {"raum": "#001619", "himmelUnten": [0, 0, 0], "himmelOben": [0.004, 0.055, 0.062], "sterne": 8031637, "sterneDeckung": 0.55, "wasserTief": [0, 0, 0], "spiegelhelle": 0.25, "glanz": [0.12, 0.6, 0.62], "schicht": {"F": "#50E8F4", "S": "#02A0A0", "N": "#316C81"}, "schein": true, "tafelOben": "#0B1E24", "tafelUnten": "#001619", "tafelRand": "rgba(157,179,188,.22)", "tafelEcke": "rgba(2,160,160,.85)", "tafelNummer": "rgba(80,232,244,.9)", "tafelNeben": "rgba(159,178,185,.6)", "tafelFrei": "rgba(30,49,56,.95)", "tafelFuss": "rgba(159,178,185,.5)", "etikett": "#EDF2F4", "etikettSchatten": "rgba(0,0,0,.7)"};
  var KARTEN = [{"titel": "Funktionen", "seite": "funktionen.html"}, {"titel": "Branchen", "seite": "branchen.html"}, {"titel": "Preise", "seite": "preise.html"}, {"titel": "Sicherheit", "seite": "sicherheit.html"}, {"titel": "Wissen", "seite": "wissen.html"}, {"titel": "Über uns", "seite": "ueber-uns.html"}, {"titel": "Kontakt", "seite": "kontakt.html"}, {"titel": "Fragen", "seite": "faq.html"}];
  var ZYKLUS = ["F","F","F","F","F","-","-","S","S","S","S","S","-","-","N","N","N","N","N","-","-","-","-","-"];

  var P = {
    /* Konvex: die Kamera steht außerhalb, die Tafeln liegen auf der
       Außenhaut einer Trommel. Deshalb ist die Wölbung je Tafel negativ
       (die Ränder weichen von der Kamera zurück, nicht zu ihr hin), der
       Bildwinkel enger und die Kamera um `abstand` von der Haut entfernt. */
    ringRadius: 8.5, kartenB: 1.68, kartenH: 2.74, woelbung: -1, luecke: 0.36,
    hub: 0.05, eckradius: 0.035, hebung: 1.035, abstand: 9.6,
    fov: 46, augenhoehe: 2.52, eigendreh: 0.04, zugtempo: 0.0085, nachlauf: 0.89,
    spiegelhelle: 0.25, wellenmass: 0.68, verzerrung: 0.1, glanz: 0.04,
    fresnel: 2.1, etikettabstand: 0.2,
  };

  var renderer;
  try {
    renderer = new THREE.WebGL1Renderer({ canvas: leinwand, antialias: true });
  } catch (e) { abschnitt.classList.add("flach"); return; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  var DPR = renderer.getPixelRatio();

  var szene = new THREE.Scene();
  szene.background = new THREE.Color(T.raum);

  var kamera = new THREE.PerspectiveCamera(P.fov, 1, 0.1, 220);
  kamera.position.set(0, P.augenhoehe, P.ringRadius + P.abstand);
  var blick = new THREE.Vector3(0, 1.05, 0);
  kamera.lookAt(blick);

  /* ── Himmel: fast schwarz, im Zenit ein Rest Nachtblau ── */
  var himmel = new THREE.Mesh(
    new THREE.SphereGeometry(180, 32, 24),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false,
      vertexShader: "varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }",
      uniforms: { uUnten: { value: new THREE.Vector3().fromArray(T.himmelUnten) },
                  uOben: { value: new THREE.Vector3().fromArray(T.himmelOben) } },
      fragmentShader: [
        "precision highp float; varying vec3 vP;",
        "uniform vec3 uUnten, uOben;",
        "void main(){",
        "  float h = normalize(vP).y;",
        "  vec3 col = mix(uUnten, uOben, smoothstep(0.02, 0.72, h));",
        "  gl_FragColor = vec4(pow(max(col, 0.0), vec3(1.0/2.2)), 1.0);",
        "}",
      ].join("\n"),
    }));
  himmel.renderOrder = -1;
  szene.add(himmel);

  /* ── Sternfeld: 700 stille Punkte, deterministisch gesetzt ── */
  (function () {
    var N = 700, pos = new Float32Array(N * 3), keim = 1234.5;
    var rnd = function () { keim = Math.sin(keim * 12.9898 + 78.233) * 43758.5453; return keim - Math.floor(keim); };
    for (var i = 0; i < N; i++) {
      var r = 70 + rnd() * 80, th = rnd() * Math.PI * 2, ph = (rnd() * 0.6 + 0.2) * Math.PI;
      pos[i * 3] = Math.sin(ph) * Math.cos(th) * r;
      pos[i * 3 + 1] = Math.abs(Math.cos(ph)) * r * 0.7 + 5;
      pos[i * 3 + 2] = Math.sin(ph) * Math.sin(th) * r;
    }
    var g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    szene.add(new THREE.Points(g, new THREE.PointsMaterial({
      color: T.sterne, size: 0.16, sizeAttenuation: true,
      transparent: true, opacity: T.sterneDeckung, depthWrite: false })));
  })();

  /* ── Tafelbilder: prozedural gezeichnet, in der Sprache des Blatts ── */
  /* Auf Dunkel: Fluorescent Blue, Traditional Turquoise, Vintage Aqua */
  var FARBE = T.schicht;
  function pfadRund(x, l, o, b, h, r) {
    x.beginPath();
    x.moveTo(l + r, o);
    x.arcTo(l + b, o, l + b, o + h, r);
    x.arcTo(l + b, o + h, l, o + h, r);
    x.arcTo(l, o + h, l, o, r);
    x.arcTo(l, o, l + b, o, r);
    x.closePath();
  }
  function tafelBild(idx) {
    var b = document.createElement("canvas");
    b.width = 512; b.height = 836;
    var x = b.getContext("2d");
    var grad = x.createLinearGradient(0, 0, 0, 836);
    grad.addColorStop(0, T.tafelOben); grad.addColorStop(1, T.tafelUnten);
    x.fillStyle = grad; x.fillRect(0, 0, 512, 836);
    x.strokeStyle = T.tafelRand; x.lineWidth = 2;
    x.strokeRect(18, 18, 476, 800);
    x.strokeStyle = T.tafelEcke; x.lineWidth = 3;
    x.beginPath(); x.moveTo(18, 44); x.lineTo(18, 18); x.lineTo(44, 18); x.stroke();
    x.beginPath(); x.moveTo(494, 792); x.lineTo(494, 818); x.lineTo(468, 818); x.stroke();
    x.font = "500 24px Zaehl, ui-monospace, monospace";
    x.fillStyle = T.tafelNummer; x.textAlign = "left";
    x.fillText("N\u00BA " + ("0" + (idx + 1)).slice(-2), 46, 82);
    x.fillStyle = T.tafelNeben; x.textAlign = "right";
    x.fillText("24/6", 466, 82);
    /* Das Leuchtfeld: der Zyklus, je Tafel mit eigenem Startpunkt —
       die Tafeln sind das einzige Licht im Raum. */
    for (var g2 = 0; g2 < 6; g2++) {
      for (var r2 = 0; r2 < 13; r2++) {
        var tag = r2 + idx * 3;
        var st = ZYKLUS[(((tag - g2 * 4) % 24) + 24) % 24];
        var px = 46 + g2 * 76, py = 130 + r2 * 50;
        x.save();
        if (st === "-") {
          x.strokeStyle = T.tafelFrei; x.lineWidth = 1.5;
          pfadRund(x, px, py, 40, 44, 20); x.stroke();
        } else {
          x.shadowColor = FARBE[st];
          x.shadowBlur = T.schein ? (st === "F" ? 30 : st === "S" ? 18 : 8) : 0;
          x.fillStyle = FARBE[st];
          pfadRund(x, px, py, 40, 44, 20); x.fill();
        }
        x.restore();
      }
    }
    x.font = "500 20px Zaehl, ui-monospace, monospace";
    x.fillStyle = T.tafelFuss; x.textAlign = "left";
    x.fillText("CENTRIC", 46, 806);
    return b;
  }
  function etikettBild(text) {
    var b = document.createElement("canvas");
    b.width = 1024; b.height = 96;
    var x = b.getContext("2d");
    x.font = "500 46px Lauf, system-ui, sans-serif";
    try { x.letterSpacing = "7px"; } catch (e) {}
    x.textAlign = "center"; x.textBaseline = "middle";
    x.shadowColor = T.etikettSchatten; x.shadowBlur = 12;
    x.fillStyle = T.etikett;
    x.fillText(text.toUpperCase(), 512, 52);
    return b;
  }

  /* ── Der Ring: Tafeln auf den Zylinder gewölbt ── */
  function gewoelbt(w, h, R, k) {
    var g = new THREE.PlaneGeometry(w, h, 28, 1), pos = g.attributes.position;
    for (var i = 0; i < pos.count; i++) {
      var x = pos.getX(i), d = x / R;
      var cx = R * Math.sin(d), cz = R * (1 - Math.cos(d));
      pos.setX(i, x + (cx - x) * k);
      pos.setZ(i, cz * k);
    }
    pos.needsUpdate = true;
    return g;
  }
  function tafelMaterial(map) {
    return new THREE.ShaderMaterial({
      uniforms: {
        map: { value: map },
        uAspect: { value: P.kartenB / P.kartenH },
        uBildAspect: { value: 512 / 836 },
        uRadius: { value: P.eckradius },
      },
      transparent: true, extensions: { derivatives: true },
      vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }",
      fragmentShader: [
        "#extension GL_OES_standard_derivatives : enable",
        "precision highp float;",
        "uniform sampler2D map; uniform float uAspect, uBildAspect, uRadius; varying vec2 vUv;",
        "float sdRR(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r; }",
        "void main(){",
        "  vec2 p = (vUv - 0.5); p.x *= uAspect;",
        "  float d = sdRR(p, vec2(0.5 * uAspect, 0.5), uRadius);",
        "  float aa = max(fwidth(d), 1e-4);",
        "  float innen = 1.0 - smoothstep(0.0, aa, d);",
        "  if(innen < 0.003) discard;",
        "  vec2 s = uAspect > uBildAspect ? vec2(1.0, uBildAspect / uAspect) : vec2(uAspect / uBildAspect, 1.0);",
        "  vec2 iuv = (vUv - 0.5) * s + 0.5;",
        "  gl_FragColor = vec4(texture2D(map, iuv).rgb, innen);",
        "}",
      ].join("\n"),
    });
  }

  var rondell = new THREE.Group(); szene.add(rondell);
  rondell.rotation.y = 0;            /* Tafel 01 beginnt vorn in der Mitte */
  var tafeln = [], neuzeichnen = [], RING_N = 0;
  (function () {
    var umfang = 2 * Math.PI * P.ringRadius;
    RING_N = Math.max(KARTEN.length, Math.floor(umfang / (P.kartenB + P.luecke)));
    var y = P.hub + P.kartenH / 2;
    var aniso = renderer.capabilities.getMaxAnisotropy();
    for (var i = 0; i < RING_N; i++) {
      var k = i % KARTEN.length;
      var a = (i / RING_N) * Math.PI * 2;
      var g = new THREE.Group();
      g.position.set(Math.sin(a) * P.ringRadius, y, Math.cos(a) * P.ringRadius);
      g.rotation.y = a;
      g.userData = { mass: 1, seite: KARTEN[k].seite };

      var tex = new THREE.CanvasTexture(tafelBild(k));
      tex.anisotropy = aniso;
      var mesh = new THREE.Mesh(
        gewoelbt(P.kartenB, P.kartenH, P.ringRadius, P.woelbung), tafelMaterial(tex));
      mesh.userData.gruppe = g;
      g.add(mesh); tafeln.push(mesh);

      var et = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.206),
        new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(etikettBild(KARTEN[k].titel)),
          transparent: true, opacity: 0.68, depthWrite: false }));
      et.position.set(0, P.kartenH / 2 + P.etikettabstand + 0.1, 0.02);
      g.add(et);

      (function (m, e2, kk) {
        neuzeichnen.push(function () {
          var t2 = new THREE.CanvasTexture(tafelBild(kk)); t2.anisotropy = aniso;
          m.material.uniforms.map.value = t2;
          e2.material.map = new THREE.CanvasTexture(etikettBild(KARTEN[kk].titel));
          e2.material.needsUpdate = true;
        });
      })(mesh, et, k);
      rondell.add(g);
    }
  })();

  /* ── Wasser: Spur, Wellen, echte planare Spiegelung ── */
  var SPUR_N = 14, spur = [];
  for (var si = 0; si < SPUR_N; si++) spur.push(new THREE.Vector3(0, 0, -1000));
  var spiegelRT = new THREE.WebGLRenderTarget(2, 2,
    { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
  var spiegelKam = new THREE.PerspectiveCamera();
  var texMatrix = new THREE.Matrix4();
  var wu = {
    tReflect: { value: spiegelRT.texture }, uTexMatrix: { value: texMatrix },
    uTime: { value: 0 }, uCamPos: { value: new THREE.Vector3() },
    uReflBright: { value: T.spiegelhelle },
    uGlanzR: { value: T.glanz[0] }, uGlanzG: { value: T.glanz[1] },
    uGlanzB: { value: T.glanz[2] }, uRipScale: { value: P.wellenmass },
    uRipDistort: { value: P.verzerrung }, uGlint: { value: P.glanz },
    uFresnel: { value: P.fresnel }, uTrail: { value: spur },
    uTief: { value: new THREE.Vector3().fromArray(T.wasserTief) },
  };
  var wasser = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.ShaderMaterial({
    uniforms: wu,
    vertexShader: "precision highp float; uniform mat4 uTexMatrix; varying vec4 vRefl; varying vec3 vWpos; void main(){ vec4 wp = modelMatrix * vec4(position,1.); vWpos = wp.xyz; vRefl = uTexMatrix * vec4(position,1.); gl_Position = projectionMatrix * viewMatrix * wp; }",
    fragmentShader: [
      "precision highp float;",
      "#define SPUR_N 14",
      "uniform sampler2D tReflect; uniform float uTime, uReflBright, uRipScale, uRipDistort, uGlint, uFresnel;",
      "uniform float uGlanzR, uGlanzG, uGlanzB;",
      "uniform vec3 uCamPos, uTief; uniform vec3 uTrail[SPUR_N];",
      "varying vec4 vRefl; varying vec3 vWpos;",
      "void wave(vec2 p, vec2 d, float k, float w, float a, inout vec2 grad){ grad += a * k * cos(dot(d,p)*k + uTime*w) * d; }",
      "void main(){",
      "  vec2 p = vWpos.xz; vec2 grad = vec2(0.0); float A = uRipScale;",
      "  wave(p, normalize(vec2( 1.0, 0.35)), 1.7, 1.30, 0.045*A, grad);",
      "  wave(p, normalize(vec2(-0.6, 1.0 )), 2.4, 1.05, 0.034*A, grad);",
      "  wave(p, normalize(vec2( 0.4,-1.0 )), 3.6, 1.70, 0.022*A, grad);",
      "  wave(p, normalize(vec2(-1.0,-0.2 )), 5.1, 2.20, 0.013*A, grad);",
      "  float kamm = 0.0;",
      "  for(int i=0;i<SPUR_N;i++){",
      "    vec3 e = uTrail[i]; float alter = uTime - e.z;",
      "    if(alter > 0.0 && alter < 2.4){",
      "      float d = distance(p, e.xy); float rad = alter * 2.1;",
      "      float band = exp(-pow((d - rad) * 3.2, 2.0)); float abkling = (1.0 - alter / 2.4);",
      "      vec2 dir = d > 1e-4 ? (p - e.xy) / d : vec2(0.0);",
      "      grad += dir * (-sin((d - rad) * 9.0) * 9.0 * band * abkling * 0.010 * A);",
      "      kamm += cos((d - rad) * 9.0) * band * abkling;",
      "    }",
      "  }",
      "  vec3 N = normalize(vec3(-grad.x, 1.0, -grad.y));",
      "  vec3 V = normalize(uCamPos - vWpos);",
      "  vec2 ruv = vRefl.xy / vRefl.w; ruv += N.xz * uRipDistort;",
      "  vec3 spiegel = pow(texture2D(tReflect, clamp(ruv, 0.001, 0.999)).rgb, vec3(2.2)) * uReflBright;",
      "  float fres = 0.02 + 0.95 * pow(1.0 - clamp(dot(V, N), 0.0, 1.0), uFresnel);",
      "  vec3 col = mix(uTief, spiegel, fres);",
      "  vec3 gdir = normalize(vec3(0.2, 1.0, -0.3)); vec3 H = normalize(gdir + V);",
      "  float spec = pow(clamp(dot(N, H), 0.0, 1.0), 200.0);",
      "  col += vec3(uGlanzR, uGlanzG, uGlanzB) * spec * uGlint;",
      "  col += spiegel * max(kamm, 0.0) * 0.09;",
      "  float dist = length(vWpos.xz - uCamPos.xz);",
      "  col = mix(col, uTief, smoothstep(14.0, 50.0, dist));",
      "  gl_FragColor = vec4(pow(max(col, vec3(0.0)), vec3(1.0/2.2)), 1.0);",
      "}",
    ].join("\n"),
  }));
  wasser.rotation.x = -Math.PI / 2;
  szene.add(wasser);

  /* Gespiegelte Kamera mit schiefem Nahclip — nichts unter dem Wasser
     schlägt in die Spiegelung durch. */
  var _rN = new THREE.Vector3(), _rW = new THREE.Vector3(), _cW = new THREE.Vector3();
  var _rot = new THREE.Matrix4(), _la = new THREE.Vector3(), _vw = new THREE.Vector3();
  var _tg = new THREE.Vector3(), _q = new THREE.Vector4(), _cl = new THREE.Vector4();
  var _pl = new THREE.Plane();
  function spiegelung() {
    _rW.setFromMatrixPosition(wasser.matrixWorld);
    _cW.setFromMatrixPosition(kamera.matrixWorld);
    _rot.extractRotation(wasser.matrixWorld); _rN.set(0, 0, 1).applyMatrix4(_rot);
    _vw.subVectors(_rW, _cW); if (_vw.dot(_rN) > 0) return;
    _vw.reflect(_rN).negate().add(_rW);
    _rot.extractRotation(kamera.matrixWorld);
    _la.set(0, 0, -1).applyMatrix4(_rot).add(_cW);
    _tg.subVectors(_rW, _la).reflect(_rN).negate().add(_rW);
    spiegelKam.position.copy(_vw);
    spiegelKam.up.set(0, 1, 0).applyMatrix4(_rot).reflect(_rN);
    spiegelKam.lookAt(_tg);
    spiegelKam.far = kamera.far; spiegelKam.updateMatrixWorld();
    spiegelKam.projectionMatrix.copy(kamera.projectionMatrix);
    texMatrix.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
    texMatrix.multiply(spiegelKam.projectionMatrix);
    texMatrix.multiply(spiegelKam.matrixWorldInverse);
    texMatrix.multiply(wasser.matrixWorld);
    _pl.setFromNormalAndCoplanarPoint(_rN, _rW).applyMatrix4(spiegelKam.matrixWorldInverse);
    _cl.set(_pl.normal.x, _pl.normal.y, _pl.normal.z, _pl.constant);
    var M = spiegelKam.projectionMatrix;
    _q.x = (Math.sign(_cl.x) + M.elements[8]) / M.elements[0];
    _q.y = (Math.sign(_cl.y) + M.elements[9]) / M.elements[5];
    _q.z = -1.0; _q.w = (1.0 + M.elements[10]) / M.elements[14];
    _cl.multiplyScalar(2.0 / _cl.dot(_q));
    M.elements[2] = _cl.x; M.elements[6] = _cl.y;
    M.elements[10] = _cl.z + 1.0; M.elements[14] = _cl.w;
    wasser.visible = false;
    var vorher = renderer.getRenderTarget();
    renderer.setRenderTarget(spiegelRT); renderer.clear();
    renderer.render(szene, spiegelKam);
    renderer.setRenderTarget(vorher);
    wasser.visible = true;
  }

  /* ── Eingaben: Ziehen (mit Nachlauf), Heben, Wellenspur, Öffnen ── */
  var zieht = false, letztesX = 0, drall = 0, zugweite = 0;
  var mausZiel = new THREE.Vector2(), maus = new THREE.Vector2(), ndc = new THREE.Vector2();
  var strahl = new THREE.Raycaster();
  var schwebt = null, wach = 0;
  function anstossen(n) { wach = Math.max(wach, n || 2); }
  function ndcSetzen(e, ziel) {
    var r = leinwand.getBoundingClientRect();
    ziel.set(((e.clientX - r.left) / r.width) * 2 - 1,
             -(((e.clientY - r.top) / r.height) * 2 - 1));
  }
  var _ro = new THREE.Vector3(), _rd = new THREE.Vector3();
  function zeigerAufWasser(e) {
    ndcSetzen(e, ndc); strahl.setFromCamera(ndc, kamera);
    _ro.copy(strahl.ray.origin); _rd.copy(strahl.ray.direction);
    if (_rd.y > -1e-4) return null;
    var t = -_ro.y / _rd.y;
    if (t <= 0 || t > 80) return null;
    return { x: _ro.x + _rd.x * t, z: _ro.z + _rd.z * t };
  }
  var spurKopf = 0, lRx = 1e9, lRz = 1e9;
  function tropfen(e) {
    if (ruhig) return;
    var w = zeigerAufWasser(e); if (!w) return;
    if (Math.hypot(w.x - lRx, w.z - lRz) < 0.14) return;
    spur[spurKopf].set(w.x, w.z, wu.uTime.value);
    spurKopf = (spurKopf + 1) % SPUR_N; lRx = w.x; lRz = w.z;
  }
  function oeffnen(seite) {
    if (document.querySelector(".seite")) location.hash = "#" + seite;
    else location.href = seite;
  }
  leinwand.addEventListener("pointerdown", function (e) {
    zieht = true; zugweite = 0; letztesX = e.clientX; drall = 0;
    leinwand.classList.add("-zieht"); leinwand.setPointerCapture(e.pointerId);
    tropfen(e); document.body.classList.add("-gezogen"); anstossen(2);
  });
  leinwand.addEventListener("pointermove", function (e) {
    ndcSetzen(e, mausZiel); tropfen(e); anstossen(2);
    if (zieht) {
      var dx = e.clientX - letztesX; letztesX = e.clientX; zugweite += Math.abs(dx);
      var d = dx * P.zugtempo; rondell.rotation.y += d; drall = d;
    }
  });
  leinwand.addEventListener("pointerup", function () {
    if (zieht && zugweite < 6 && schwebt) oeffnen(schwebt.userData.seite);
    zieht = false; leinwand.classList.remove("-zieht");
  });
  leinwand.addEventListener("pointercancel", function () {
    zieht = false; leinwand.classList.remove("-zieht");
  });
  function schwebePruefen() {
    if (zieht) { schwebt = null; return; }
    strahl.setFromCamera(mausZiel, kamera);
    var traf = strahl.intersectObjects(tafeln, false)[0];
    schwebt = traf ? traf.object.userData.gruppe : null;
    leinwand.style.cursor = schwebt ? "pointer" : "";
  }

  /* ── Fokuszeile: verfolgt die Tafel vorn in der Mitte ── */
  var fokusName = document.getElementById("fokus-name");
  var fokusNum = document.getElementById("fokus-num");
  var fokusLink = document.getElementById("fokus-link");
  var punkteWrap = document.getElementById("fokus-punkte");
  document.getElementById("fokus-total").textContent = ("0" + KARTEN.length).slice(-2);
  var punkte = KARTEN.map(function () {
    var d = document.createElement("i"); punkteWrap.appendChild(d); return d;
  });
  var fokusIdx = -1;
  function fokusAngleichen() {
    var platz = Math.round((-rondell.rotation.y) / (2 * Math.PI) * RING_N);
    platz = ((platz % RING_N) + RING_N) % RING_N;
    var idx = platz % KARTEN.length;
    if (idx === fokusIdx) return;
    fokusIdx = idx;
    fokusName.textContent = KARTEN[idx].titel;
    fokusNum.textContent = ("0" + (idx + 1)).slice(-2);
    fokusLink.href = KARTEN[idx].seite;
    for (var i = 0; i < punkte.length; i++) punkte[i].classList.toggle("-an", i === idx);
    fokusName.classList.remove("-tausch"); void fokusName.offsetWidth;
    fokusName.classList.add("-tausch");
  }

  /* ── Maße, Sichtbarkeit, Schleife ── */
  var sichtbar = true;
  if ("IntersectionObserver" in window) {
    new IntersectionObserver(function (es) {
      sichtbar = es[0].isIntersecting; if (sichtbar) anstossen(3);
    }).observe(abschnitt);
  }
  function messen() {
    var r = abschnitt.getBoundingClientRect();
    var w = Math.max(2, r.width | 0), h = Math.max(2, r.height | 0);
    renderer.setSize(w, h, false);
    kamera.aspect = w / h; kamera.updateProjectionMatrix();
    /* Von außen hängt die Bildeinstellung am Seitenverhältnis: auf einem
       hochkant gehaltenen Telefon ist der waagerechte Bildwinkel schmal,
       und die Trommel würde angeschnitten. Der Abstand wächst deshalb so
       weit, dass ihr Umriss hineinpasst — und nie so weit, dass die
       Kamera in die Trommel geriete. */
    var halbSenkr = P.fov * Math.PI / 360;
    var halbWaagr = Math.atan(Math.tan(halbSenkr) * kamera.aspect);
    var noetig = P.ringRadius / Math.sin(Math.max(0.2, halbWaagr * 0.86));
    /* Nach oben gedeckelt: auf einem hochkant gehaltenen Telefon müsste die
       Kamera sonst über fünfzig Einheiten zurück, damit der ganze Umriss
       hineinpasst — die Tafeln wären winzig. Dort ist Anschneiden besser
       als Schrumpfen. */
    kamera.position.z = Math.min(P.ringRadius + 14,
                                 Math.max(P.ringRadius + 5, noetig));
    kamera.lookAt(blick);
    spiegelRT.setSize(Math.max(2, Math.floor(w * DPR)), Math.max(2, Math.floor(h * DPR)));
    anstossen(3);
  }
  if ("ResizeObserver" in window) new ResizeObserver(messen).observe(abschnitt);
  messen();
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(function () {
      for (var i = 0; i < neuzeichnen.length; i++) neuzeichnen[i]();
      anstossen(3);
    });
  }

  var vorherT = performance.now(), startT = vorherT;
  function bild() {
    requestAnimationFrame(bild);
    var jetzt = performance.now();
    var dt = Math.min((jetzt - vorherT) / 1000, 0.05);
    vorherT = jetzt;
    if (!sichtbar) return;
    if (ruhig && wach <= 0) return;
    if (wach > 0) wach--;
    if (!ruhig) {
      if (!zieht) { rondell.rotation.y += drall + P.eigendreh * dt; drall *= P.nachlauf; }
      wu.uTime.value = (jetzt - startT) / 1000;
    } else if (!zieht) { drall = 0; }
    schwebePruefen(); fokusAngleichen();
    for (var i = 0; i < rondell.children.length; i++) {
      var g = rondell.children[i];
      var ziel = (g === schwebt) ? P.hebung : 1;
      g.userData.mass += (ziel - g.userData.mass) * Math.min(1, dt * 12);
      g.scale.setScalar(g.userData.mass);
    }
    maus.lerp(mausZiel, 0.06);
    kamera.position.x = maus.x * 0.35;
    kamera.position.y = P.augenhoehe + maus.y * 0.18;
    kamera.lookAt(blick);
    wu.uCamPos.value.copy(kamera.position);
    spiegelung();
    renderer.render(szene, kamera);
  }
  anstossen(6);
  bild();
})();
